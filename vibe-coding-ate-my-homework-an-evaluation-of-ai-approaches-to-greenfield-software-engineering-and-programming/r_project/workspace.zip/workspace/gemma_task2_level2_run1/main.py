import json
import io
import sys
import types
class TrackingDict(dict):
   def __init__(self, history_size=5):
      super().__init__()
      self.history_size = history_size
      self.history = []  # Stores (name, value) pairs

   def __setitem__(self, key, value):
      # Track only non-internal variables (skip __builtins__, etc.)
      if (
         not key.startswith("__")
         and not isinstance(value, types.ModuleType)
         and not isinstance(value, types.FunctionType)
      ):
         self.history.append((key, value))
         if len(self.history) > self.history_size:
            self.history.pop(0)
      super().__setitem__(key, value)

   def last_list(self):
      """Return the last N assignments as a list of (name, value) pairs."""
      return list(self.history)

def make_json_safe(value):
   if isinstance(value, (str, int, float, bool)) or value is None:
      return value
   elif isinstance(value, list):
      return [make_json_safe(v) for v in value]
   elif isinstance(value, dict):
      return {str(k): make_json_safe(v) for k, v in value.items()}
   else:
      return repr(value)

last_user_locals = []

def trace_locals(frame, event, arg):
   if event == "return":
      global last_user_locals
      frame_globals = frame.f_globals
      frame_name = frame.f_code.co_name
      if (
         frame_globals.get("__name__") == "__main__"
         and frame_name not in {"trace_locals", "make_json_safe", "__setitem__", "last_list"}
      ):
         current_locals = []
         for name, value in frame.f_locals.items():
            if (
               not name.startswith("__")
               and name not in {"self", "key", "value", "frame", "event", "arg", "frame_globals", "frame_name"}
               and not isinstance(value, types.ModuleType)
               and not isinstance(value, types.FunctionType)
            ):
               current_locals.append((name, make_json_safe(value)))
         if len(current_locals) > 0:
            last_user_locals = current_locals
   return trace_locals


old_stdout = sys.stdout
sys.stdout = buffer = io.StringIO()
# Create a tracking namespace
tracker_ns = TrackingDict(history_size=3)
tracker_ns["__name__"] = "__main__"

# Example program code
program_code = "import matplotlib.pyplot as plt\n\n# Data for the line\nx = [i for i in range(6)]\ny = [i for i in range(6)]\n\n# Create the plot\nplt.plot(x, y)\n\n# Set the axis limits\nplt.xlim(0, 5)\nplt.ylim(0, 5)\n\n# Add labels and title\nplt.xlabel('X-axis')\nplt.ylabel('Y-axis')\nplt.title('Y = X')\n\n# Save the plot\nplt.savefig('line_graph.png')\n\n# Show the plot (optional)\nplt.show()"
result_path = "/users/40290129/vibe-coding-ate-my-homework-an-evaluation-of-ai-approaches-to-greenfield-software-engineering-and-programming/r_project/workspace/gemma_task2_level2_run1/result.json"

listOfVariables = []
localVariables = []
status = 'executed_ok'
try:
   sys.settrace(trace_locals)
   # Execute inside the tracking namespace
   exec(program_code, tracker_ns)

   # Retrieve the last tracked assignments
   listOfVariables = [
      (name, make_json_safe(value)) for name, value in tracker_ns.last_list()
   ]
   localVariables = list(last_user_locals)
   executed = True
except Exception as e:
   executed = False
   status = 'runtime_error'
finally:
   sys.settrace(None)
   sys.stdout = old_stdout
   stdout = buffer.getvalue()
with open(result_path, 'w') as f:
   json.dump({'executed': executed, 'variablesCreated': listOfVariables, 'localVariables': localVariables, 'stdout': stdout, 'status': status}, f)
